import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ord',
  templateUrl: './ord.component.html',
  styleUrls: ['./ord.component.css']
})
export class OrdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
