import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coustdel',
  templateUrl: './coustdel.component.html',
  styleUrls: ['./coustdel.component.css']
})
export class CoustdelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
