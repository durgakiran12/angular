import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoustdelComponent } from './coustdel.component';

describe('CoustdelComponent', () => {
  let component: CoustdelComponent;
  let fixture: ComponentFixture<CoustdelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoustdelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoustdelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
