import { Component, OnInit } from '@angular/core';

import { Pipe, PipeTransform } from '@angular/core';


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  

  constructor() { }

  ngOnInit(): void {
  }
  
  filteredString: string = '';


    public card = [
    {Id:'1',M:'assets/images/m1.png',Name:'Ted',Last:'James',full:'Ted James',Address:'Pheonix, Arizona',A:'ViewOrders'},

    {Id:'2',M:'assets/images/g2.png',Name:'Michelle',Last:'Thompson',full:'Michelle Thompson',Address:'Seattle, Washington',A:'ViewOrders'},
    
    {Id:'3',M:'assets/images/m2.png',Name:'Zed',Last:'Bishop',full:'Zed Bishop',Address:'Seattle, Washington',A:'ViewOrders'}
   ];
  
   filtered1String: string = '';


    public card1 = [
    {Id:'1',M1:'assets/images/7.png',Name:'Nina',Last:'Adams',full:'Nina Adams',Address:'Pheonix, Arizona',A:'ViewOrders'},

    {Id:'2',M1:'assets/images/g1.png',Name:'Igor',Last:'Minar',full:'Igor Minar',Address:'Seattle, Washington',A:'ViewOrders'},
    
    {Id:'3',M1:'assets/images/m21.png',Name:'Brad',Last:'Green',full:'Brad Green',Address:'Seattle, Washington',A:'ViewOrders'}
   ];
  
  
}
