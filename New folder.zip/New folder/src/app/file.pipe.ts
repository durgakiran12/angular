import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter1'
})
export class Filter1Pipe implements PipeTransform {

  transform(value: any, filter1String:string) {
    if (value.length ==0 || filter1String ===''){
      return value;
    }

    const cards =  [];
    for (const card1 of value){
      if (card1['Name'] === filter1String){
        cards.push(card1);
      }
      if (card1['Last'] === filter1String){
        cards.push(card1);
      }
      if (card1['full'] === filter1String){
        cards.push(card1);
      }
      if (card1['Address'] === filter1String){
        cards.push(card1);
      }
    }
    return cards;
  }

}


