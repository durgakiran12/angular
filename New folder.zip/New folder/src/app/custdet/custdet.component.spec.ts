import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustdetComponent } from './custdet.component';

describe('CustdetComponent', () => {
  let component: CustdetComponent;
  let fixture: ComponentFixture<CustdetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustdetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustdetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
