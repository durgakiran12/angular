import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custdet',
  templateUrl: './custdet.component.html',
  styleUrls: ['./custdet.component.css']
})
export class CustdetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
