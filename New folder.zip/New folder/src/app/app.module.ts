import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { ListviewComponent } from './listview/listview.component';
import { OrdersComponent } from './orders/orders.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { CardComponent } from './card/card.component';
import { TedComponent } from './ted/ted.component';
import { EditComponent } from './edit/edit.component';
import { AddComponent } from './add/add.component';
import { SerComponent } from './ser/ser.component';
import { MapComponent } from './map/map.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { SearchFilterPipe } from './card/search-filter.pipe';
import { CoustupComponent } from './coustup/coustup.component';
import { CoustdelComponent } from './coustdel/coustdel.component';
import { Pg2Component } from './pg2/pg2.component';
import { CustdetComponent } from './custdet/custdet.component';
import { OrdComponent } from './ord/ord.component';
import { FilterPipe } from './filter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Filter1Pipe } from './file.pipe';
@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    ListviewComponent,
    OrdersComponent,
    AboutComponent,
    LoginComponent,
    CardComponent,
    TedComponent,
    EditComponent,
    AddComponent,
    SerComponent,
    MapComponent,
    SearchFilterPipe,
    CoustupComponent,
    CoustdelComponent,
    Pg2Component,
    CustdetComponent,
    OrdComponent,
    FilterPipe,
    Filter1Pipe
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
