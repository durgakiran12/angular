import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any, filterString:string) {
    if (value.length ==0 || filterString ===''){
      return value;
    }

    const cards =  [];
    for (const card of value){
      if (card['Name'] === filterString){
        cards.push(card);
      }
      if (card['Last'] === filterString){
        cards.push(card);
      }
      if (card['full'] === filterString){
        cards.push(card);
      }
      if (card['Address'] === filterString){
        cards.push(card);
      }
    }
    return cards;
  }

}


