import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listview',
  templateUrl: './listview.component.html',
  styleUrls: ['./listview.component.css']
})
export class ListviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  filteredString: string = '';


  public card = [
  {Id:'1',M:'assets/images/m1.png',Name:'Ted James',Address:'Pheonix, Arizona',A:'ViewOrders'},

  {Id:'2',M:'assets/images/m2.png',Name:'Michelle Thompson',Address:'Seattle, Washington',A:'ViewOrders'},
  
  {Id:'3',M:'assets/images/m2.png',Name:'Zed Bishop',Address:'Seattle, Washington',A:'ViewOrders'}
 ];

 public card1 = [
  {Id:'1',a:'assets/images/m1.png',Name:'Ted James',Address:'Pheonix, Arizona',A:'ViewOrders'},

  {Id:'2',a:'assets/images/m2.png',Name:'Michelle Thompson',Address:'Seattle, Washington',A:'ViewOrders'},
  
  {Id:'3',a:'assets/images/m2.png',Name:'Zed Bishop',Address:'Seattle, Washington',A:'ViewOrders'}
 ];
}
