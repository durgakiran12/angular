import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ted',
  templateUrl: './ted.component.html',
  styleUrls: ['./ted.component.css']
})
export class TedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
