import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coustup',
  templateUrl: './coustup.component.html',
  styleUrls: ['./coustup.component.css']
})
export class CoustupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
