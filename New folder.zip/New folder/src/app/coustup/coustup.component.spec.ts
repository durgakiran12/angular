import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoustupComponent } from './coustup.component';

describe('CoustupComponent', () => {
  let component: CoustupComponent;
  let fixture: ComponentFixture<CoustupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoustupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoustupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
