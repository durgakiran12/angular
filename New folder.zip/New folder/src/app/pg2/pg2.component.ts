import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pg2',
  templateUrl: './pg2.component.html',
  styleUrls: ['./pg2.component.css']
})
export class Pg2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
